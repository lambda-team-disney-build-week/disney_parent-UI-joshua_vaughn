Thank you for your interest in my fonts.  These are
"emailware", a phrase I made up, meaning: drop me a note
if you enjoy them.  If you love them so much that you
feel you must donate $1 or some fonts, you can find
my address below.

These were created for my own personal use in scrapbooking
and letter writing.  I shared a few with friends and
eventually with font groups.  I have made them available
for download on my website:

DingBrats
http://www.geocities.com/dingbrats/

These are for personal use only and may not be used in
any commercial way.  Some of these fonts have characters
which I do not hold the copyright to.  They may be removed
from the site at any time.

Use at your own risk and enjoy!

Jenna
dingbrats@yahoo.com

Jenna
PO Box 92976
Henderson, NV 89009-2976
USA